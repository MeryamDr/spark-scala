import function._
import org.apache.spark.sql.functions.col
import org.apache.spark.sql
import org.apache.spark.sql.functions._
import scala.math.BigInt
import Sales_2013._
object Sales_2013except {

  def main(args: Array[String]): Unit = {
    val Sales = fun_Sales
    val Sales_2013 = Sales
      .where(col("timestamp").contains("2013"))
    val refund_list= fun_Refund.groupBy("txID").count()

    val new_sales =Sales_2013.join(refund_list,Sales_2013("txID")===refund_list("txID"),"leftanti")
    new_sales.show()
    new_sales.select(sum("amount")).withColumnRenamed("sum(amount)","le montant total sauf le remboursement")
      .show()








  }

}
