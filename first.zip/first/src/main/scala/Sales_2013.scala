import function._
import org.apache.spark.sql.functions.col
import org.apache.spark.sql
import org.apache.spark.sql.functions._


object Sales_2013 {
  def main(args: Array[String]): Unit = {

    val Sales = fun_Sales
    val Sales_2013 = Sales
      .where(col("timestamp").contains("2013"))
      .groupBy()
      .sum("amount")
    Sales_2013.withColumnRenamed("sum(amount)","montant total")show()

    }



















}
