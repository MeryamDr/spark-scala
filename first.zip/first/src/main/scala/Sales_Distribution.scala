import function._
import org.apache.spark.sql.functions.col

object Sales_Distribution {

  def main(args: Array[String]): Unit = {
    val Sales= fun_Sales
    val Products= fun_Product
    var Sales_Dist =Sales.groupBy("prodID").sum("amount","quantity")
    Sales_Dist = Sales_Dist.join(Products,Sales_Dist("prodID")===Products("prodID"),"inner")
      .select(
        col("name").as("nom du produit"),
        col("sum(amount)").as("La somme totale"),
        col("sum(quantity)").as("La qualité totale"))
    Sales_Dist.show()

  }

}
