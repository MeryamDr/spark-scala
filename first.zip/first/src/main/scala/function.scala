import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types._
import org.apache.spark.sql.{Dataset, Encoder, Encoders, Row, SparkSession, types}


object function {
  val sc: SparkSession = SparkSession.builder()
    .master("local")
    .appName("SparkApp")
    .getOrCreate()

  def fun_Product: org.apache.spark.sql.DataFrame ={

    val Product_sc = StructType(Array(
      StructField("prodID", IntegerType, false),
      StructField("name", StringType, false),
      StructField("type", StringType, false),
      StructField("version", StringType, false),
      StructField("price", IntegerType, false),

    ))
    val Product = sc.read
      .option("sep", "|")
      .option("header", false)
      .schema(Product_sc)
      .csv("Product.txt")
    return Product
  }
  def fun_Sales: org.apache.spark.sql.DataFrame ={
    val sale = "Sales.txt"
    val Sales_sc = StructType(Array(
      StructField("txID", IntegerType, false),
      StructField("custID", IntegerType, false),
      StructField("prodID", IntegerType, false),
      StructField("timestamp", StringType, true),
      StructField("amount", IntegerType, false),
      StructField("quantity", IntegerType, false)
    ))
    val Sales = sc.read
      .option("sep", "|")
      .option("header", true)
      .schema(Sales_sc)
      .csv(sale)
    return Sales
  }
  def fun_Refund :org.apache.spark.sql.DataFrame ={
    val Refund_sc = StructType(Array(

      StructField("refID", IntegerType, false),
      StructField("txID", IntegerType, false),
      StructField("custID", IntegerType, false),
      StructField("prodID", IntegerType, false),
      StructField("timestamp", StringType, false),
      StructField("amount", IntegerType, false),
      StructField("quantity", IntegerType, false)
    ))
    val Refund = sc.read
      .option("sep", "|")
      .option("header", true)
      .schema(Refund_sc)
      .csv("Refund.txt")
    return Refund
  }
  def fun_customer :org.apache.spark.sql.DataFrame ={
    val Customer_sc = StructType(Array(
      StructField("CustID", IntegerType, false),
      StructField("Firstname", StringType, false),
      StructField("Lastname", StringType, false),
      StructField("Phone", StringType, true)
    ))
    val Customer = sc.read
      .option("sep", "|")
      .option("header", true)
      .schema(Customer_sc)
      .csv("Customer.txt")
    return Customer
  }




  def main(args:Array[ String]) : Unit = {

    this.fun_Product.show()
    this.fun_Product.printSchema()
    this.fun_Sales.show()
    this.fun_Sales.printSchema()
    this.fun_Refund.show()
    this.fun_Refund.printSchema()
    this.fun_customer.show()
    this.fun_customer.printSchema()


  }




}
