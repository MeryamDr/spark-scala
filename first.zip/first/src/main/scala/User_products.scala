import function._
import org.apache.spark.sql.functions.col



object User_products {
  def main(args: Array[String]): Unit = {
    val customer = fun_customer.alias("C")
    val sales = fun_Sales
    val customerID   = sales.groupBy("custID").sum("quantity","amount").alias("CI")
    customerID.join(customer).where(customer("custID")===customerID("custID")).select(col("CI.CustID"),
      col("C.Lastname"),col("C.Firstname"),col("CI.sum(quantity)").as("la quantité totale"),
      col("sum(amount)").as("montant total")).show()
  }

}
